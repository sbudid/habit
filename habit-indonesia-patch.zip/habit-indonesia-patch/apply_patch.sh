#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-.}"

copy_file() {
  local src="$1"
  local dest="$ROOT_DIR/$src"
  mkdir -p "$(dirname "$dest")"
  cp "$src" "$dest"
  echo "Updated $dest"
}

copy_file "app/pages/index.vue"
copy_file "app/pages/[user].vue"
copy_file "app/app.vue"
copy_file "app/app.config.ts"
copy_file "app/components/AppHeader.vue"
copy_file "app/components/AppFooter.vue"
copy_file "app/components/EmptyHabits.vue"
copy_file "app/components/HabitForm.vue"
copy_file "app/components/ProfileHeader.vue"
copy_file "docs/NEXT_STEPS_INDONESIA.md"
copy_file "package.json"

echo "Done. Run: pnpm install && pnpm dev"
