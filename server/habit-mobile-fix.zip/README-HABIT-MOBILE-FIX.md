# Habit mobile bug fix

Patch ini untuk repository `sbudid/habit`, bukan `sbudid/dentalbaru`.

Perubahan:

1. Mengganti layout utama dari tinggi terkunci (`h-dvh`) menjadi tinggi minimum (`min-h-dvh`) agar konten panjang tidak terdorong keluar dari bagian atas layar.
2. Menambahkan ruang aman untuk notch/status bar dan area gesture bawah.
3. Membuat modal tambah habit responsif dan bisa di-scroll pada layar kecil.
4. Menambahkan tombol X di modal.
5. Membuat tombol Back Android menutup modal lebih dahulu, bukan langsung keluar dari PWA/app.

## Cara pasang dari Codespaces

Upload `habit-mobile-fix.patch` ke root repository `habit`, lalu jalankan:

```bash
git checkout -b fix/mobile-layout-and-modal-back
git apply --check habit-mobile-fix.patch
git apply habit-mobile-fix.patch
bun install
bun run build
git add .
git commit -m "Fix mobile viewport and add habit modal back behavior"
git push origin fix/mobile-layout-and-modal-back
```

Bila repository memakai npm, gunakan `npm install` dan `npm run build`.

## Tes di HP

- Login dan buka dashboard.
- Pastikan bagian profil paling atas tidak lagi terpotong.
- Buka Add/Create Habit.
- Tekan X: modal tertutup dan tetap di dashboard.
- Buka modal lagi lalu tekan tombol Back Android: modal tertutup dan app tidak keluar.
- Pastikan form bisa di-scroll sampai tombol submit pada layar pendek.
